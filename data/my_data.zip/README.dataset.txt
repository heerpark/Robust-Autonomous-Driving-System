# yolo_od_annotation > 2025-11-18 10:18pm
https://universe.roboflow.com/yolood-1izb8/yolo_od_annotation-jssq5

Provided by a Roboflow user
License: CC BY 4.0

